var minPathSum = function(grid) {
  let row = grid.length, col = grid[0].length

  // calc boundary
  for(let i = 1; i < row; i++)
      // calc first col
      grid[i][0] += grid[i - 1][0]

  for(let j = 1; j < col; j++)
      // calc first row
      grid[0][j] += grid[0][j - 1]

  for(let i = 1; i < row; i++)
      for(let j = 1; j < col; j++)
          grid[i][j] += Math.min(grid[i - 1][j], grid[i][j - 1])
  
  return grid[row - 1][col - 1]
};